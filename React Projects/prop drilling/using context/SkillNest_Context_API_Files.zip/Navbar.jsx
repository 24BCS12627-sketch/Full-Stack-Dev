function Navbar() {
  return (
    <div>
      <h1>SkillNest</h1>
    </div>
  );
}

export default Navbar;

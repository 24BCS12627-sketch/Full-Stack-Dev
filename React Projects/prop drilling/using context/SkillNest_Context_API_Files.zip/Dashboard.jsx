import CourseCatalog from "./courseCatalog";

function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <CourseCatalog />
    </div>
  );
}

export default Dashboard;

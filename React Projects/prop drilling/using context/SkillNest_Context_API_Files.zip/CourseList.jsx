import StudentProfile from "./StudentProfile";

function CourseList() {
  return (
    <div>
      <h2>Course List</h2>
      <StudentProfile />
    </div>
  );
}

export default CourseList;

# SkillNest Context API Version

This project demonstrates solving prop drilling using React Context API.

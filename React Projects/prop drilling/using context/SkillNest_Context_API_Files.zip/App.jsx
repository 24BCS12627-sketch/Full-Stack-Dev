import Navbar from "./Navbar";
import Dashboard from "./Dashboard";
import UserContext from "./UserContext";

function App() {
  const user = {
    name: "Krish",
    email: "krish@gmail.com",
    program: "Web Development",
  };

  return (
    <UserContext.Provider value={user}>
      <Navbar />
      <Dashboard />
    </UserContext.Provider>
  );
}

export default App;

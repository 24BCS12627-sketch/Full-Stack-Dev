import { useContext } from "react";
import UserContext from "./UserContext";

function StudentProfile() {
  const user = useContext(UserContext);

  return (
    <div>
      <h2>Student Details</h2>

      <p>Name: {user.name}</p>
      <p>Email: {user.email}</p>
      <p>Program: {user.program}</p>
    </div>
  );
}

export default StudentProfile;

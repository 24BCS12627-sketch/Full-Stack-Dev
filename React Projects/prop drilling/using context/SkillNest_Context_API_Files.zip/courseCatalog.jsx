import CourseList from "./CourseList";

function CourseCatalog() {
  return (
    <div>
      <h2>Course Catalog</h2>
      <CourseList />
    </div>
  );
}

export default CourseCatalog;
